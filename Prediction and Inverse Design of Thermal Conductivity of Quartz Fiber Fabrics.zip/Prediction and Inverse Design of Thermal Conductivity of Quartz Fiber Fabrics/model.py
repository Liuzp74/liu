import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
import matplotlib.pyplot as plt
import joblib

torch.manual_seed(42)
np.random.seed(42)

class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(9, 32)
        self.fc2 = nn.Linear(32, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 3)
        
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x

# ==================== 1. 数据准备（不增强，保持原分布）====================
data_path = r'D:\\Desktop\\data\\thermal_conduction.xlsx'
data = pd.read_excel(data_path)

input_features = ['a', 'b', 'c', 'xw', 'x_height', 'xs', 'yw', 'y_height', 'ys']
output_features = ['X_k_WmK', 'Y_k_WmK', 'Z_k_WmK']

X = data[input_features]
y = data[output_features]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, shuffle=True
)

print(f"训练集样本数: {len(X_train)}")

# 归一化（保持原分布）
scaler_X = MinMaxScaler()
X_train_norm = scaler_X.fit_transform(X_train)
X_test_norm = scaler_X.transform(X_test)

scaler_y = MinMaxScaler()
y_train_norm = scaler_y.fit_transform(y_train)
y_test_norm = scaler_y.transform(y_test)

# 保存
joblib.dump(scaler_X, r'D:\Desktop\data\scaler_X.joblib')
joblib.dump(scaler_y, r'D:\Desktop\data\scaler_y.joblib')

X_train_tensor = torch.tensor(X_train_norm, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train_norm, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test_norm, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test_norm, dtype=torch.float32)

train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
train_loader = DataLoader(dataset=train_dataset, batch_size=64, shuffle=True)

# ==================== 2. 训练（带对称性约束）====================
model = NeuralNetwork()
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

epochs = 1000
lambda_sym = 0.12  # 对称性约束权重，可根据需要调整（0.1-1.0）

print("\n开始训练（带对称性约束）...")
for epoch in range(epochs):
    model.train()
    total_loss_epoch = 0
    
    for inputs, targets in train_loader:
        optimizer.zero_grad()
        
        # 正常前向传播
        outputs = model(inputs)
        mse_loss = criterion(outputs, targets)
        
        # 对称性约束：构造对称输入（a=b, xw=yw...）
        # 从当前batch中构造对称样本
        inputs_sym = inputs.clone()
        # 假设列顺序：a,b,c,xw,x_height,xs,yw,y_height,ys (0,1,2,3,4,5,6,7,8)
        # 交换a(0)和b(1)，交换xw(3)和yw(6)，交换x_height(4)和y_height(7)，交换xs(5)和ys(8)
        inputs_sym[:, 0], inputs_sym[:, 1] = inputs[:, 1], inputs[:, 0]  # a↔b
        inputs_sym[:, 3], inputs_sym[:, 6] = inputs[:, 6], inputs[:, 3]  # xw↔yw
        inputs_sym[:, 4], inputs_sym[:, 7] = inputs[:, 7], inputs[:, 4]  # x_height↔y_height
        inputs_sym[:, 5], inputs_sym[:, 8] = inputs[:, 8], inputs[:, 5]  # xs↔ys
        
        # 预测对称输入
        outputs_sym = model(inputs_sym)
        
        # 对称性损失：交换输入后，X和Y输出应该互换，即outputs_sym的X应该等于outputs的Y
        # outputs: [X, Y, Z], outputs_sym: [X', Y', Z']
        # 我们希望 X' ≈ Y 且 Y' ≈ X
        sym_loss = torch.mean((outputs_sym[:, 0] - outputs[:, 1])**2 + 
                              (outputs_sym[:, 1] - outputs[:, 0])**2)
        
        # 总损失
        total_loss = mse_loss + lambda_sym * sym_loss
        total_loss.backward()
        optimizer.step()
        
        total_loss_epoch += total_loss.item()
    
    if (epoch + 1) % 100 == 0:
        print(f'Epoch [{epoch+1}/{epochs}], Loss: {total_loss_epoch:.6f}')

# ==================== 3. 评估 ====================
model.eval()
with torch.no_grad():
    y_pred_train_norm = model(X_train_tensor).numpy()
    y_pred_train = scaler_y.inverse_transform(y_pred_train_norm)
    
    y_pred_test_norm = model(X_test_tensor).numpy()
    y_pred_test = scaler_y.inverse_transform(y_pred_test_norm)

# 打印评估指标...
print("\n最终评估：")
for i, feature in enumerate(output_features):
    train_r2 = r2_score(y_train.iloc[:, i], y_pred_train[:, i])
    test_r2 = r2_score(y_test.iloc[:, i], y_pred_test[:, i])
    print(f"{feature}: Train R²={train_r2:.4f}, Test R²={test_r2:.4f}")

# ==================== 4. 对称性验证 ====================
print("\n" + "="*50)
print("对称性验证：")
test_sym = torch.tensor([[1, 1, 1, 0.8, 0.1, 1, 0.8, 0.1, 1]], dtype=torch.float32)  # a=b, xw=yw...
test_sym_norm = scaler_X.transform(test_sym.numpy())
test_sym_tensor = torch.tensor(test_sym_norm, dtype=torch.float32)

with torch.no_grad():
    pred_sym = model(test_sym_tensor).numpy()
    pred_sym = scaler_y.inverse_transform(pred_sym)

print(f"输入: a=b=1, xw=yw=0.8, x_height=y_height=0.1, xs=ys=1")
print(f"预测 X_k: {pred_sym[0,0]:.8f}")
print(f"预测 Y_k: {pred_sym[0,1]:.8f}")
print(f"差异: {abs(pred_sym[0,0] - pred_sym[0,1]):.2e}")

# ==================== 5. 保存模型 ====================
torch.save({
    'model_state_dict': model.state_dict(),
    'input_features': input_features,
    'output_features': output_features,
}, r'D:\Desktop\data\thermal_conduction_model.pth')

print("\n✅ 模型已保存")