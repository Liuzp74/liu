import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from scipy.optimize import differential_evolution
import joblib
import time
from datetime import datetime
import json
from math import gcd
import warnings
warnings.filterwarnings('ignore')

# ==================== 配置区域 ====================
# 请修改为您的实际路径（注意：model_4 保存的是字典格式）
CONFIG = {
    'model_path': r'D:\Desktop\data\data_2\thermal_conduction_model.pth',  # model_4 保存的路径
    'scaler_X_path': r'D:\Desktop\data\data_2\scaler_X.joblib',
    'scaler_y_path': r'D:\Desktop\data\data_2\scaler_y.joblib',
    'output_dir': r'D:\Desktop\data\data_2',
    'target_k': [0.25, 0.25, 0.05],  # 目标导热系数
    'weights': [1.0, 1.0, 2.0],      # 权重
    'run_mode': 'optimize',          # 'diagnose' 或 'optimize'
}

# ==================== 1. 模型定义 ====================
class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(9, 32)
        self.fc2 = nn.Linear(32, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 3)
        
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x

# ==================== 2. 诊断工具类 ====================
class DiagnosticTool:
    def __init__(self, model, scaler_X, scaler_y):
        self.model = model
        self.scaler_X = scaler_X
        self.scaler_y = scaler_y
        self.param_names = ['a', 'b', 'c', 'xw', 'x_height', 'xs', 'yw', 'y_height', 'ys']
        
    def check_scaler(self):
        """检查Scaler的状态"""
        print("\n" + "="*70)
        print("【诊断】检查 Scaler 状态")
        print("="*70)
        
        print(f"Scaler_X 类型: {type(self.scaler_X).__name__}")
        
        if hasattr(self.scaler_X, 'data_min_'):
            print(f"\n参数范围:")
            for i, name in enumerate(self.param_names):
                print(f"  {name:12s}: [{self.scaler_X.data_min_[i]:8.4f}, {self.scaler_X.data_max_[i]:8.4f}]")
        
        # 测试归一化/反归一化
        print(f"\n归一化一致性测试:")
        test_val = np.array([[1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 2.0, 1.0, 2.0]])
        norm_val = self.scaler_X.transform(test_val)
        back_val = self.scaler_X.inverse_transform(norm_val)
        error = np.abs(back_val - test_val)
        print(f"  原始值: {test_val[0]}")
        print(f"  归一化: {norm_val[0]}")
        print(f"  反归一化: {back_val[0]}")
        print(f"  误差: {error[0]}")
        print(f"  状态: {'✓ 正常' if np.max(error) < 1e-6 else '✗ 异常'}")
        
        return norm_val[0, :3]  # 返回 a,b,c=1 的归一化值
    
    def test_fixed_norm(self):
        """测试 fixed_norm 的正确计算"""
        print("\n" + "="*70)
        print("【诊断】测试 fixed_norm 计算 (a=b=c=1)")
        print("="*70)
        
        # 正确的计算方法
        dummy_input = np.array([[1.0, 1.0, 1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]])
        fixed_norm = self.scaler_X.transform(dummy_input)[0, :3]
        
        print(f"输入: [1,1,1,0.5,0.5,0.5,0.5,0.5,0.5]")
        print(f"fixed_norm (a,b,c归一化值): {fixed_norm}")
        print(f"注意: 如果这是[0,0,0]，说明训练数据中1是最小值，可能正常")
        print(f"      但如果后续测试显示几何参数变化无影响，则可能是问题所在")
        
        return fixed_norm
    
    def test_sensitivity(self, fixed_norm):
        """测试模型敏感性"""
        print("\n" + "="*70)
        print("【诊断】模型敏感性测试")
        print("="*70)
        
        print("\n测试1: 固定 a=b=c=1，改变几何参数 xw")
        print("-" * 60)
        
        xw_values = np.linspace(0, 1, 11)
        results = []
        
        for xw in xw_values:
            geom = np.array([xw, 0.5, 0.5, 0.5, 0.5, 0.5])
            full_input = np.concatenate([fixed_norm, geom])
            x_tensor = torch.tensor([full_input], dtype=torch.float32)
            
            with torch.no_grad():
                pred_norm = self.model(x_tensor).numpy()
                pred_k = self.scaler_y.inverse_transform(pred_norm)[0]
            
            results.append(pred_k)
            print(f"xw={xw:.1f} -> k=[{pred_k[0]:.6f}, {pred_k[1]:.6f}, {pred_k[2]:.6f}]")
        
        results = np.array(results)
        k_range = np.max(results, axis=0) - np.min(results, axis=0)
        
        print(f"\nX方向变化范围: {k_range[0]:.6f}")
        print(f"Y方向变化范围: {k_range[1]:.6f}")
        print(f"Z方向变化范围: {k_range[2]:.6f}")
        
        if np.max(k_range) < 1e-6:
            print("\n⚠️ 警告: 几何参数变化几乎不影响输出！")
            print("   这意味着优化器会误判为已收敛")
            return False
        else:
            print("\n✓ 几何参数对输出有影响，优化器应该能正常工作")
            return True
    
    def test_abc_sensitivity(self):
        """测试材料参数敏感性"""
        print("\n" + "="*70)
        print("【诊断】材料参数 (a,b,c) 敏感性测试")
        print("="*70)
        
        abc_tests = [
            (1, 1, 1),
            (1, 2, 1),
            (2, 2, 2),
            (3, 4, 5),
        ]
        
        print("固定几何参数为0.5，改变 a,b,c:")
        for a, b, c in abc_tests:
            test_input = np.array([[a, b, c, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]])
            test_norm = self.scaler_X.transform(test_input)
            
            x_tensor = torch.tensor(test_norm, dtype=torch.float32)
            with torch.no_grad():
                pred_norm = self.model(x_tensor).numpy()
                pred_k = self.scaler_y.inverse_transform(pred_norm)[0]
            
            print(f"a={a},b={b},c={c} -> k=[{pred_k[0]:.4f}, {pred_k[1]:.4f}, {pred_k[2]:.4f}]")

# ==================== 3. 修复后的优化器 ====================
class ThermalOptimizerFixed:
    def __init__(self, target_k, model, scaler_X, scaler_y, weights=None):
        self.target_k = np.array(target_k)
        self.model = model
        self.scaler_X = scaler_X
        self.scaler_y = scaler_y
        self.weights = weights if weights is not None else np.array([1.0, 1.0, 1.0])
        self.history = []
        self.eval_count = 0
        
        # 关键修复：正确计算 fixed_norm
        dummy_input = np.array([[1.0, 1.0, 1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]])
        self.fixed_norm = self.scaler_X.transform(dummy_input)[0, :3].copy()
        
        print(f"Fixed Norm 初始化: {self.fixed_norm}")
        print(f"反归一化验证: {self.scaler_X.inverse_transform(dummy_input)[0, :3]}")
        
    def objective(self, x_norm_6):
        """
        目标函数：6维输入（几何参数）
        修复：确保 fixed_norm 正确拼接
        """
        self.eval_count += 1
        
        # 将6维优化参数与3维固定参数拼接
        full_x_norm = np.concatenate([self.fixed_norm, x_norm_6])
        
        # 预测
        x_tensor = torch.tensor([full_x_norm], dtype=torch.float32)
        with torch.no_grad():
            pred_norm = self.model(x_tensor).numpy()
            pred_k = self.scaler_y.inverse_transform(pred_norm)[0]
        
        # 计算加权MSE
        mse = np.sum(self.weights * (pred_k - self.target_k) ** 2)
        
        # 记录 - 包含绘图所需的全部信息
        self.history.append({
            'eval': self.eval_count,
            'geom': x_norm_6.copy(),
            'pred_k': pred_k.copy(),
            'mse': mse,
            'k_x': pred_k[0],
            'k_y': pred_k[1],
            'k_z': pred_k[2]
        })
        
        # 每50步打印一次
        if self.eval_count % 50 == 0:
            print(f"Eval {self.eval_count:4d}: MSE={mse:.6e}, k=[{pred_k[0]:.4f}, {pred_k[1]:.4f}, {pred_k[2]:.4f}]")
        
        return mse
    
    def optimize(self, maxiter=200, popsize=15):
        """运行优化"""
        print(f"\n开始优化: maxiter={maxiter}, popsize={popsize}")
        print(f"参数边界: [0,1] x 6")
        
        bounds = [(0, 1)] * 6
        
        start_time = time.time()
        
        result = differential_evolution(
            self.objective,
            bounds,
            maxiter=maxiter,
            popsize=popsize,
            mutation=(0.5, 1),
            recombination=0.7,
            seed=42,
            polish=True,
            tol=1e-8,
            atol=1e-8,
            disp=False  # 我们手动打印
        )
        
        opt_time = time.time() - start_time
        
        print(f"\n优化完成!")
        print(f"耗时: {opt_time:.2f} 秒")
        print(f"评估次数: {self.eval_count}")
        print(f"迭代次数: {result.nit}")
        print(f"成功: {result.success}")
        
        # 处理结果
        best_geom_norm = result.x
        best_full_norm = np.concatenate([self.fixed_norm, best_geom_norm])
        best_original = self.scaler_X.inverse_transform([best_full_norm])[0]
        
        # 强制 a,b,c 精确为1
        best_original[0], best_original[1], best_original[2] = 1, 1, 1
        
        # 最终预测
        with torch.no_grad():
            final_pred = self.model(torch.tensor([best_full_norm], dtype=torch.float32))
            final_k = self.scaler_y.inverse_transform(final_pred.numpy())[0]
        
        return best_original, final_k, result

# ==================== 4. 主程序 ====================
def main():
    print("="*70)
    print("热导率优化程序 (model_4 适配版 - 含对称性约束)")
    print("时间:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("="*70)
    
    # 加载模型（适配 model_4 格式）
    print("\n正在加载模型...")
    try:
        model = NeuralNetwork()
        
        # ==================== 关键修改部分 ====================
        # model_4 保存的是字典，包含 model_state_dict 和特征信息
        checkpoint = torch.load(CONFIG['model_path'], map_location='cpu')
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()
        
        # 打印 model_4 的额外信息（验证加载成功）
        print("✓ 模型加载成功 (来自 model_4)")
        if 'input_features' in checkpoint:
            print(f"  输入特征: {checkpoint['input_features']}")
        if 'output_features' in checkpoint:
            print(f"  输出特征: {checkpoint['output_features']}")
        # =====================================================
        
        scaler_X = joblib.load(CONFIG['scaler_X_path'])
        scaler_y = joblib.load(CONFIG['scaler_y_path'])
        
    except Exception as e:
        print(f"✗ 加载失败: {e}")
        print("请检查路径配置:")
        print(f"  模型路径: {CONFIG['model_path']}")
        print(f"  Scaler_X: {CONFIG['scaler_X_path']}")
        print(f"  Scaler_y: {CONFIG['scaler_y_path']}")
        return
    
    # 运行诊断
    if CONFIG['run_mode'] == 'diagnose':
        print("\n进入诊断模式...")
        diag = DiagnosticTool(model, scaler_X, scaler_y)
        
        # 检查scaler
        fixed_norm = diag.check_scaler()
        
        # 测试fixed_norm
        fixed_norm = diag.test_fixed_norm()
        
        # 测试敏感性
        is_sensitive = diag.test_sensitivity(fixed_norm)
        
        # 测试abc敏感性
        diag.test_abc_sensitivity()
        
        print("\n" + "="*70)
        print("诊断建议:")
        if not is_sensitive:
            print("⚠️  发现关键问题: 几何参数变化不影响输出")
            print("   可能原因:")
            print("   1. fixed_norm 计算错误 (检查是否为[0,0,0])")
            print("   2. 模型训练时几何参数就被忽略")
            print("   3. Scaler范围问题导致几何参数变化被压缩")
        else:
            print("✓ 模型敏感性正常，可以进行优化")
        print("="*70)
    
    # 运行优化
    else:
        print("\n进入优化模式...")
        
        # 先快速诊断
        diag = DiagnosticTool(model, scaler_X, scaler_y)
        fixed_norm = diag.test_fixed_norm()
        is_ok = diag.test_sensitivity(fixed_norm)
        
        if not is_ok:
            print("\n⚠️ 警告: 模型对几何参数不敏感，优化可能提前收敛")
            proceed = input("是否继续? (y/n): ")
            if proceed.lower() != 'y':
                return
        
        # 运行优化
        optimizer = ThermalOptimizerFixed(
            target_k=CONFIG['target_k'],
            model=model,
            scaler_X=scaler_X,
            scaler_y=scaler_y,
            weights=CONFIG['weights']
        )
        
        best_params, best_k, result = optimizer.optimize(maxiter=200, popsize=15)
        
        # 显示结果
        print("\n" + "="*70)
        print("优化结果 (使用 model_4 对称约束模型)")
        print("="*70)
        
        param_names = ['a', 'b', 'c', 'xw', 'x_height', 'xs', 'yw', 'y_height', 'ys']
        print("\n最优参数:")
        for i, (name, val) in enumerate(zip(param_names, best_params)):
            marker = " (固定)" if i < 3 else " (优化)"
            print(f"  {name:12s}: {val:10.6f}{marker}")
        
        print(f"\n目标 vs 预测:")
        target = np.array(CONFIG['target_k'])
        for i, direction in enumerate(['X', 'Y', 'Z']):
            error = abs(best_k[i] - target[i])
            rel_error = (error / target[i]) * 100
            print(f"  {direction}: 目标={target[i]:.4f}, 预测={best_k[i]:.4f}, 误差={rel_error:.4f}%")
        
        # ==================== 保存结果到Excel ====================
        try:
            excel_path = f"{CONFIG['output_dir']}\\optimization_results_model4.xlsx"
            
            # 1. 创建历史数据DataFrame
            history_df = pd.DataFrame(optimizer.history)
            history_df['log_mse'] = np.log10(history_df['mse'])
            
            # 2. 最优参数DataFrame
            df_result = pd.DataFrame({
                '参数名': param_names,
                '最优值': best_params,
                '归一化值': np.concatenate([optimizer.fixed_norm, result.x]),
                '类型': ['材料(固定)']*3 + ['几何(优化)']*6
            })
            
            # 3. 对比数据DataFrame
            df_comparison = pd.DataFrame({
                '方向': ['X方向', 'Y方向', 'Z方向'],
                '目标值': CONFIG['target_k'],
                '预测值': best_k,
                '绝对误差': np.abs(best_k - target),
                '相对误差(%)': (np.abs(best_k - target) / target) * 100
            })
            
            # 4. 创建专门用于绘图的数据Sheet
            convergence_data = pd.DataFrame({
                '评估次数': history_df['eval'],
                'MSE': history_df['mse'],
                'log10_MSE': history_df['log_mse']
            })
            
            k_evolution_data = pd.DataFrame({
                '评估次数': history_df['eval'],
                'k_x': history_df['k_x'],
                'k_y': history_df['k_y'],
                'k_z': history_df['k_z'],
                '目标_k_x': CONFIG['target_k'][0],
                '目标_k_y': CONFIG['target_k'][1],
                '目标_k_z': CONFIG['target_k'][2]
            })
            
            comparison_wide = pd.DataFrame({
                '方向': ['X', 'Y', 'Z'],
                '目标': CONFIG['target_k'],
                '预测': best_k
            })
            
            geom_params = df_result[df_result['类型'] == '几何(优化)'].copy()
            param_plot_data = pd.DataFrame({
                '参数名': geom_params['参数名'],
                '最优值': geom_params['最优值'],
                '归一化值': geom_params['归一化值']
            })
            
            # 写入Excel
            with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
                history_df.to_excel(writer, sheet_name='优化历史', index=False)
                convergence_data.to_excel(writer, sheet_name='图a_收敛曲线', index=False)
                k_evolution_data.to_excel(writer, sheet_name='图b_导热系数演化', index=False)
                comparison_wide.to_excel(writer, sheet_name='图c_对比数据', index=False)
                df_comparison.to_excel(writer, sheet_name='对比详细', index=False)
                df_result.to_excel(writer, sheet_name='图d_最优参数', index=False)
                param_plot_data.to_excel(writer, sheet_name='几何参数绘图', index=False)
                
                # 配置信息（标注使用 model_4）
                config_df = pd.DataFrame({
                    '配置项': ['模型来源', '目标k_x', '目标k_y', '目标k_z', '权重_x', '权重_y', '权重_z', 
                              '总评估次数', '最终MSE', '优化时间'],
                    '值': ['model_4_with_symmetry_constraint',
                          CONFIG['target_k'][0], CONFIG['target_k'][1], CONFIG['target_k'][2],
                          CONFIG['weights'][0], CONFIG['weights'][1], CONFIG['weights'][2],
                          optimizer.eval_count, 
                          float(history_df['mse'].iloc[-1]) if len(history_df) > 0 else None,
                          datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                })
                config_df.to_excel(writer, sheet_name='配置信息', index=False)
            
            print(f"\n✓ 结果已保存至: {excel_path}")
            print(f"  注意: 本次优化使用 model_4（带对称性约束）训练的模型")
            
        except Exception as e:
            print(f"\n保存Excel失败: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    main()